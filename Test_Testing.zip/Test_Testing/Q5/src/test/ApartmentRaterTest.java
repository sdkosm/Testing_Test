package com.realestateapp;

import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.realestateapp.ApartmentRater;

public class ApartmentRaterTest {

//	double area = 200;
//	double price = 50000;
  
	@Test
	void calculateAverageRating() {

		List<Apartment> ApartmentEmptyList = Collections.<Apartment>emptyList();
		assertThrows(RuntimeException.class, () -> ApartmentRater.calculateAverageRating(ApartmentEmptyList));

	}

	@Nested
	class Apartment_NotEmptyTest {
		
		// Test  cases 1 for testing by given data
		
		@Test
		void Is_Apartment_NotEmptyTest() {
			double area = 20;                                                              //area of  apartment 1 20.0
			BigDecimal price = new BigDecimal(250000.00);            // price for apartment 1  250000.0
			Apartment apartment1 = new Apartment(area, price);

			List<Apartment> List = new ArrayList<>();
			List.add(apartment1);
			assertEquals(0.0, ApartmentRater.calculateAverageRating(List));

		}
 
		// Test  cases 2 for testing by given data
		
		@Test
		void Is_Apartment_NotEmptyTest1() {
			double area = 30.0;                                                     //area of  apartment 2   30.0
			BigDecimal price = new BigDecimal(350000.00);    // price for apartment 2   350000.0
			Apartment apartment1 = new Apartment(area, price);

			List<Apartment> List = new ArrayList<>();
			List.add(apartment1);
			assertEquals(-1.0, ApartmentRater.calculateAverageRating(List));

		}
		
		// Test  cases 3 for testing by given data

		@Test
		void Is_Apartment_NotEmptyTest2() {
			double area = 40.0;
			BigDecimal price = new BigDecimal(600000.00);                //area of  apartment 3   40.0
			Apartment apartment1 = new Apartment(area, price);      // price for apartment 3  600000.0

			List<Apartment> List = new ArrayList<>();
			List.add(apartment1);
			assertEquals(1.0, ApartmentRater.calculateAverageRating(List));

		}
	}
}