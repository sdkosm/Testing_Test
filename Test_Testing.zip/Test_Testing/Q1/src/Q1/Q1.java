package Q1;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Q1 {
	
	public static WebDriver driver;
    
	@BeforeMethod
    public void start() {
		
	System.setProperty("webdriver.chrome.driver","D:\\JAVA NEXTURN\\Testing\\Driver\\cromedriver.exe");
    driver= new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://opensource-demo.orangehrmlive.com/");
    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
	}
	@Test(priority=1)
	public void LandingPage() {
		System.out.println(driver.getCurrentUrl());
		String CurrentURL="https://opensource-demo.orangehrmlive.com/";
		if(CurrentURL.equals("https://opensource-demo.orangehrmlive.com/")) {
			System.out.println("Test case Landing page is Pass");
		}else {
			System.out.println("Test Case LandingPage is Fail");
		}

	} 

